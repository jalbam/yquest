------------------------------
What is Server2Go
------------------------------
Server2Go is a CD-ROm Webserver. That means it is a webserver that can run directly from cdrom without installation. Server2Go allows you to create a working web site or PHP application on a CD-ROM. Using a web browser, a user can run php programs as well as view html files on the CD-ROM. He only need to insert a CD with Server2Go under the supported Windows operations systems. The server starts automaticly and opens a browser with the Website of the CD-ROM

Server2Go supports PHP5, SQLite and MySQL.

------------------------------
Community
------------------------------
You will get support, latest downloads and other things under http://www.server2go-web.de

------------------------------
Documentation
------------------------------
The documentation is available after the start of server2go.exe. If you have problems starting the server you can start it directly under htdocs/documentaion/documentation.html


------------------------------
Licence
------------------------------
Server2Go is Donationware. That means you can download and use it for free and you don't have to pay any royalty charges when distribute an application on CD-ROM that uses Server2Go. But if you use it commercially or like to keep it free available you should donate to the project. How to donate? Just take a look at the donation page. There are a lot of inexpensive possibilities to help.
Every donator that is donating more then 10.- Euro is getting a user id and password with that he can download additional software that is not public available. See the download page for details. 

------------------------------
Features
------------------------------
Free! No royalties 
Runs directly from CD-ROM 
Full featured webserver (based on apache) 
PHP 5.1.4 support with many extensions installed (i.e. gd) 
Supports SQLite databases 
Running on all Windows Win 98 and newer 
Support for MySQL Databases 
Ssupport for Perl 5.8 



Happy coding 

Timo Haberkern